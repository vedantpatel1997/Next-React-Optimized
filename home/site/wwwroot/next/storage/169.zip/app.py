# app.py
from flask import Flask
from VPPackage import greet

app = Flask(__name__)
__version__ = 1.3

@app.route('/')
def home():
    message = greet()
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Package Message</title>
  <style>
    body {{
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f2f2f2;
      margin: 0;
      padding: 20px;
    }}
    .container {{
      max-width: 600px;
      margin: 40px auto;
      background: #fff;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      padding: 30px;
      text-align: center;
    }}
    .message {{
      font-size: 1.5rem;
      color: #333;
      margin-bottom: 10px;
    }}
    .version {{
      font-size: 1.2rem;
      color: #555;
    }}
  </style>
</head>
<body>
  <div class="container">
    <div class="message">Dev-ops feeds package: {message}</div>
    <div class="version">Version number: {__version__}</div>
  </div>
</body>
</html>"""
    return html

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
