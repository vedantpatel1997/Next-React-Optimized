python -m venv venv
venv\Scripts\activate

pip install setuptools wheel twine keyring
python setup.py sdist bdist_wheel  
python -m twine upload --repository Custom-package dist/* --verbose

pip install -r requirements.txt
python app.py