# setup.py
from setuptools import setup, find_packages

setup(
    name='VPPackage',
    version='1.1',
    packages=find_packages(),
    author="Vedant Patel",
    author_email="vedantp9@gmail.com",
    description="A simple package, with greet function",
    install_requires=[],  # Add dependencies if needed
)