def greet():
    return "Hello from VPPackage 1.0!"